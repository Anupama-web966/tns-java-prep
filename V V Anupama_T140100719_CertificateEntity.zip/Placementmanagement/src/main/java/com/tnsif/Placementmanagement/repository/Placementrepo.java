package com.tnsif.Placementmanagement.repository;

import org.springframework.data.repository.CrudRepository;

import com.tnsif.Placementmanagement.entity.Certificate;
//all sql queries in this interface
public interface Placementrepo extends CrudRepository <Certificate, Long>{

}
