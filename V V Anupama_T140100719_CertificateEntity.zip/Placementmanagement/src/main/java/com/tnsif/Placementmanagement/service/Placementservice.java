package com.tnsif.Placementmanagement.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.tnsif.Placementmanagement.repository.Placementrepo;
import com.tnsif.Placementmanagement.entity.Certificate;

@Service
public class Placementservice {
	
	@Autowired //obj without new
	private Placementrepo pr;
	
	//create //methods
	public Certificate registerCertificate(Certificate c) {
		return pr.save(c);
	}
	//read
	public Iterable<Certificate> getCertificates() {
        return pr.findAll();
    }

    // Read By Id
    public Certificate getCertificate(long id) {
        return pr.findById(id).orElse(null);
    }

    // Update
    public Certificate updateCertificate(Certificate c) {
        return pr.save(c);
    }

    // Delete
    public void deleteCertificate(long id) {
        pr.deleteById(id);
    }
}

