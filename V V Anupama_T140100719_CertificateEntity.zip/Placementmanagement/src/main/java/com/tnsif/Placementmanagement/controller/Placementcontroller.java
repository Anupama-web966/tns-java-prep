package com.tnsif.Placementmanagement.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;

import com.tnsif.Placementmanagement.service.Placementservice;
import com.tnsif.Placementmanagement.entity.Certificate;


@RestController
public class Placementcontroller {
	@Autowired
	private Placementservice ps;
	
	@PostMapping("/Certificate")//savedata
	public Certificate registerCertificate(@RequestBody Certificate s) {
		return ps.registerCertificate(s);
	}
	@GetMapping("/getCertificate")
	public Iterable<Certificate> getCertificate(){
		return ps.getCertificates();
	}
	@PutMapping("/updateCertificate")
	public Certificate updateCertificate(@RequestBody Certificate c){
		return ps.updateCertificate(c);
	}
	@DeleteMapping("/deleteCertificate/{id}")
	public void deleteCertificate(@PathVariable Long id) {
		ps.deleteCertificate(id);
	}
}
