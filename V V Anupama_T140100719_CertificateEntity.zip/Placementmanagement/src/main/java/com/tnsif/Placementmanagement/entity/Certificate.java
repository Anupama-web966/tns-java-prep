package com.tnsif.Placementmanagement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Table;

@Entity
@Table
public class Certificate {
	
    @Id //primarykey
    @GeneratedValue //generates value automatically
	private long id;
	private int year;
	private String College;
	public long getId() {
		return id;
	}
	//getters and setters
	public void setId(long id) {
		this.id = id;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getCollege() {
		return College;
	}
	public void setCollege(String college) {
		College = college;
	}
	
	
 
}
